

var basic_count = 0;
var price;
var flag = 0;

const Basic_price = document.getElementById('Basic_price');
const Basic_count = document.getElementById('Basic_count');
var Basic_previous = 0;
var Pro_previous = 0;
document.getElementById('Basic_minus').addEventListener("click", function () {

    basic_count--;
    if (basic_count <= 0) basic_count = 0;
    price = 199 * basic_count;

    document.getElementById("Basic_sign").classList.remove('clicked');
    if (basic_count == Basic_previous) document.getElementById("Basic_sign").classList.add('clicked');
    Basic_price.innerHTML = '$ ' + price;
    if (basic_count > 0)
        Basic_count.innerHTML = basic_count + ' room';
    else Basic_count.innerHTML = '';

}
);

document.getElementById('Basic_plus').addEventListener("click", function () {


    basic_count++;
    price = 199 * basic_count;
    document.getElementById("Basic_sign").classList.remove('clicked');
    if (basic_count == Basic_previous) document.getElementById("Basic_sign").classList.add('clicked');
    Basic_price.innerHTML = '$ ' + price;
    Basic_count.innerHTML = basic_count + ' room';

}
);



var pro_count = 0;

const Pro_price = document.getElementById('Pro_price');
const Pro_count = document.getElementById('Pro_count');

document.getElementById('Pro_minus').addEventListener("click", function () {


    pro_count--;
    if (pro_count <= 0) pro_count = 0;
    price = 249 * pro_count;
    document.getElementById("Pro_sign").classList.remove('clicked');

    if (pro_count == Pro_previous) document.getElementById("Pro_sign").classList.add('clicked');
    Pro_price.innerHTML = '$ ' + price;
    if (pro_count > 0)
        Pro_count.innerHTML = pro_count + ' room';
    else Pro_count.innerHTML = '';

}
);

document.getElementById('Pro_plus').addEventListener("click", function () {

    pro_count++;
    price = 249 * pro_count;
    document.getElementById("Pro_sign").classList.remove('clicked');
    if (pro_count == Pro_previous) document.getElementById("Pro_sign").classList.add('clicked');
    Pro_price.innerHTML = '$ ' + price;
    Pro_count.innerHTML = pro_count + ' room';

}
);









document.getElementById("Basic_sign").addEventListener('click', function () {



    if (basic_count > 0) {

        document.getElementById("Basic_sign").classList.add('clicked');
        var row = document.getElementById('Hidden_row_basic');

        row.style.display = 'table-row';

        var cell = row.getElementsByTagName('td')[0];
        cell.innerHTML = 'Thank you for choosing ' + basic_count + ' room';
        Basic_previous = basic_count;

    }
    else {

        const row = document.getElementById('Hidden_row_basic');

        row.style.display = 'none';
        Basic_previous = basic_count;

    }
}

);
document.getElementById("Pro_sign").addEventListener('click', function () {


    if (pro_count > 0) {
        flag = 2;
        document.getElementById("Pro_sign").classList.add('clicked');
        var row = document.getElementById('Hidden_row_pro');

        row.style.display = 'table-row';

        var cell = row.getElementsByTagName('td')[0];
        cell.innerHTML = 'Thank you for choosing ' + pro_count + ' room';
        Pro_previous = pro_count;
    }
    else {
        const row = document.getElementById('Hidden_row_pro');

        row.style.display = 'none';
        Pro_previous = pro_count;
    }

})

const Form = document.querySelector('.Contact_form');

Form.addEventListener('submit', function (event) {

    event.preventDefault();
    sendMessage();
});
function sendMessage() {

    const Button = document.getElementById('From_submit');
    Button.innerHTML = 'Messege sent succesfully';
    const Input_tags = Form.getElementsByTagName('input');


    for (var i = 0; i < Input_tags.length; i++) {
        Input_tags[i].value = '';
    }
    setTimeout(function () {

        Button.innerHTML = 'Send Message';

    }, 2000);
}